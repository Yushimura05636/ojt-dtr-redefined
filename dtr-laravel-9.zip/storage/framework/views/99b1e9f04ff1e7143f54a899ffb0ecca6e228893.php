<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="w-full h-auto flex flex-col gap-5">
        <section class="flex md:flex-row flex-col-reverse items-center lg:justify-between w-full gap-5">
            <span class="w-full">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['nameId' => 'search','placeholder' => 'Search','small' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name_id' => 'search','placeholder' => 'Search','small' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </span>

            <span class="flex md:justify-end w-full">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['primary' => true,'leftIcon' => 'cuida--user-add-outline','label' => 'Add Intern','routePath' => 'admin.users.create','button' => true,'className' => 'px-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'leftIcon' => 'cuida--user-add-outline','label' => 'Add Intern','routePath' => 'admin.users.create','button' => true,'className' => 'px-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </span>
        </section>

        <section class="grid lg:!grid-cols-5 md:grid-cols-4 grid-cols-2 gap-5" id="user-container">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('admin.users.details', $user->id)); ?>"
                    class="p-5 border border-gray-200 rounded-xl cursor-pointer group animate-transition hover:border-custom-orange flex flex-col gap-5 items-center justify-center h-auto w-full bg-white user-card"
                    data-name="<?php echo e(strtolower($user->firstname)); ?>" data-student_no="<?php echo e(strtolower($user->school)); ?>">

                    <div class="w-auto h-auto">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['className' => 'w-24 h-24 rounded-full border border-custom-orange','path' => 'resources/img/default-male.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['className' => 'w-24 h-24 rounded-full border border-custom-orange','path' => 'resources/img/default-male.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div class="text-center mx-auto w-full">
                        <h1
                            class="text-sm font-semibold group-hover:text-custom-orange animate-transition truncate capitalize">
                            <?php echo e($user->firstname); ?> <?php echo e(substr($user->middlename, 0, 1)); ?>. <?php echo e($user->lastname); ?></h1>
                        <p class="text-gray-500 truncate"><?php echo e($user->school); ?></p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <!-- Pagination Controls -->
        <section class="flex lg:flex-row flex-col gap-3 items-center justify-between w-full">
            <p class="text-sm text-gray-500">
                Showing <span id="first-item">1</span> - <span id="last-item">10</span> of <span
                    id="total-items"><?php echo e(count($users)); ?></span>
            </p>

            <div class="flex gap-3 items-center">
                <button id="prev-page"
                    class="px-4 py-2 bg-gray-300 rounded disabled:opacity-50 hover:bg-custom-orange hover:text-white animate-transition disabled:hover:bg-gray-300 disabled:hover:text-current"
                    disabled>Prev</button>
                <span id="page-info">Page 1 of </span>
                <button id="next-page"
                    class="px-4 py-2 bg-gray-300 rounded disabled:opacity-50 hover:bg-custom-orange hover:text-white animate-transition disabled:hover:bg-gray-300 disabled:hover:text-current">Next</button>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchInput = document.querySelector('[name="search"]');
        const userContainer = document.getElementById("user-container");
        const userCards = Array.from(document.querySelectorAll(".user-card"));
        const firstItem = document.getElementById("first-item");
        const lastItem = document.getElementById("last-item");
        const totalItems = document.getElementById("total-items");
        const prevPageBtn = document.getElementById("prev-page");
        const nextPageBtn = document.getElementById("next-page");
        const pageInfo = document.getElementById("page-info");

        let currentPage = 1;
        const itemsPerPage = 20; // Change this to adjust pagination size
        let filteredUsers = [...userCards]; // Start with all users

        function renderUsers() {
            userContainer.innerHTML = "";
            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            const paginatedUsers = filteredUsers.slice(start, end);

            paginatedUsers.forEach(user => userContainer.appendChild(user));

            // Update total pages dynamically
            const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
            pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;

            firstItem.textContent = filteredUsers.length === 0 ? 0 : start + 1;
            lastItem.textContent = Math.min(end, filteredUsers.length);
            totalItems.textContent = filteredUsers.length;

            prevPageBtn.disabled = currentPage === 1;
            nextPageBtn.disabled = currentPage >= totalPages;
        }


        function handleSearch() {
            const query = searchInput.value.toLowerCase();
            filteredUsers = userCards.filter(card => {
                const name = card.dataset.name;
                const studentNo = card.dataset.student_no;
                return name.includes(query) || studentNo.includes(query);
            });

            currentPage = 1; // Reset to first page after search
            renderUsers();
        }

        searchInput.addEventListener("input", handleSearch);

        prevPageBtn.addEventListener("click", () => {
            if (currentPage > 1) {
                currentPage--;
                renderUsers();
            }
        });

        nextPageBtn.addEventListener("click", () => {
            if (currentPage * itemsPerPage < filteredUsers.length) {
                currentPage++;
                renderUsers();
            }
        });

        renderUsers(); // Initial Render
    });
</script>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/admin/users/index.blade.php ENDPATH**/ ?>