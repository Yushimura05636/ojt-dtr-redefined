<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['route' => '', 'type' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['route' => '', 'type' => '']); ?>
<?php foreach (array_filter((['route' => '', 'type' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>




<a href="<?php echo e(route($route)); ?>"
    class="<?php echo e(Request::routeIs($route . '*') ? 'flex items-center gap-2 px-7 py-5 w-full border-r-8 border-custom-red font-semibold text-custom-red cursor-pointer hover:bg-gray-100' : 'hover:bg-gray-100 flex items-center gap-2 px-7 py-5 w-full border-white font-semibold text-gray-500 cursor-pointer'); ?>">
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/components/sidebar-menu.blade.php ENDPATH**/ ?>