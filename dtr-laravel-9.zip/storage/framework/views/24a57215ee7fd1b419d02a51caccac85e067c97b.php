<form id="downloadForm" action="<?php echo e(route('download.pdf')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="user" value="<?php echo e(json_encode($user, true)); ?>">
    <input type="hidden" name="yearlyTotals" value="<?php echo e(json_encode($yearlyTotals, true)); ?>">
    <input type="hidden" name="records" value="<?php echo e(json_encode($records, true)); ?>">
    <input type="hidden" name="totalHoursPerMonth" value="<?php echo e(json_encode($totalHoursPerMonth, true)); ?>">
    <input type="hidden" name="selectedMonth" value="<?php echo e($selectedMonth); ?>">
    <input type="hidden" name="selectedYear" value="<?php echo e($selectedYear); ?>">
    <input type="hidden" name="pagination" value="<?php echo e(json_encode($pagination, true)); ?>">
    <input type="hidden" name="type" value="<?php echo e(json_encode($type)); ?>">
</form>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("downloadForm").submit();
    });
</script><?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/download-dtr.blade.php ENDPATH**/ ?>