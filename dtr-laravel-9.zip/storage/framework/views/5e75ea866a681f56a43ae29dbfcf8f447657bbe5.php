<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id' => '']); ?>
<?php foreach (array_filter((['id' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div id="<?php echo e($id); ?>" class="pd-overlay hidden">
    <div
        class="w-full h-full fixed top-0 left-0 z-[100] flex items-center justify-center  overflow-x-hidden overflow-y-auto bg-black bg-opacity-70">
        <div
            class="lg:!w-2/3 w-full flex items-center justify-center p-10 transition-all ease-out opacity-0 sm:mx-auto modal-open:opacity-100 modal-open:duration-500">
            <div class="flex flex-col items-center w-full p-10 gap-5 bg-white rounded-2xl">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['title' => 'User Details Found','titleClass' => 'text-xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'User Details Found','titleClass' => 'text-xl']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="w-fit">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['className' => 'w-40 h-40 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['className' => 'w-40 h-40 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
                <div class="text-center space-y-1">
                    <h1 class="font-semibold text-xl capitalize" name="fullname">fullname_placeholder</h1>
                    <p class="text-[#F57D11]" name="email">email_placeholder</p>
                </div>

                <?php
                    $details = [
                        ['label' => 'Student No.', 'value' => '02-134523-223'],
                        ['label' => 'Phone', 'value' => '+63 9123456789'],
                        ['label' => 'QR Code', 'value' => 'dpsfkf_3jnf_34'],
                        ['label' => 'Total Hours', 'value' => '30 hours'],
                    ];
                ?>

                <div class="grid grid-cols-2 gap-4 w-full">
                    
                    <section class="p-4 border border-gray-200 bg-white rounded-lg w-full">
                        <h1 class="text-sm text-[#F53C11] font-semibold">Student No.</h1>
                        <span class="w-full flex justify-end">
                            <h1 class="text-lg text-black truncate" name="student_no">student_no_placeholder</h1>
                        </span>
                    </section>
                    <section class="p-4 border border-gray-200 bg-white rounded-lg w-full">
                        <h1 class="text-sm text-[#F53C11] font-semibold">Phone</h1>
                        <span class="w-full flex justify-end">
                            <h1 class="text-lg text-black truncate" name="phone">phone_placeholder</h1>
                        </span>
                    </section>
                    <section class="p-4 border border-gray-200 bg-white rounded-lg w-full">
                        <h1 class="text-sm text-[#F53C11] font-semibold">QR Code</h1>
                        <span class="w-full flex justify-end">
                            <h1 class="text-lg text-black truncate" name="qr_code">qr_code_placeholder</h1>
                        </span>
                    </section>
                    <section class="p-4 border border-gray-200 bg-white rounded-lg w-full">
                        <h1 class="text-sm text-[#F53C11] font-semibold">Total Hours</h1>
                        <span class="w-full flex justify-end">
                            <h1 class="text-lg text-black truncate" name="total_hours">total_hours_placeholder</h1>
                        </span>
                    </section>
                </div>
                <div class="w-full flex items-center gap-4 justify-center">
                    
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['button' => true,'name' => 'button_time_in','label' => 'Time In','primary' => true,'className' => 'px-2 text-sm w-full','big' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['button' => true,'name' => 'button_time_in','label' => 'Time In','primary' => true,'className' => 'px-2 text-sm w-full','big' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['button' => true,'name' => 'button_time_out','label' => 'Time Out','primary' => true,'className' => 'px-2 text-sm w-full','big' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['button' => true,'name' => 'button_time_out','label' => 'Time Out','primary' => true,'className' => 'px-2 text-sm w-full','big' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    
                    <div name="loading_button" class="w-full text-sm px-2 text-[#F57D11] hidden"></div>
                </div>
                <div class="w-full flex justify-center">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['label' => 'Re-scan QR Code','button' => true,'className' => 'close-modal-button hover:underline hover:text-[#F57D11] w-fit','closeModal' => ''.e($id).'','onClick' => 'location.reload(true)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Re-scan QR Code','button' => true,'className' => 'close-modal-button hover:underline hover:text-[#F57D11] w-fit','closeModal' => ''.e($id).'','onClick' => 'location.reload(true)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\infi-deployment\resources\views/components/modal/time-in-time-out-modal.blade.php ENDPATH**/ ?>