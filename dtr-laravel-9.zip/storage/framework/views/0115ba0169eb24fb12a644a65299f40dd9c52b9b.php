<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['path' => '', 'className' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['path' => '', 'className' => '']); ?>
<?php foreach (array_filter((['path' => '', 'className' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<img class="<?php echo e($className); ?> select-none" draggable="false" src="<?php echo e(asset($path)); ?>">
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/components/image.blade.php ENDPATH**/ ?>