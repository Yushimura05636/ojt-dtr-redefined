<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['imgPath' => '', 'routePath' => '', 'title', 'desc', 'btnLabel' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['imgPath' => '', 'routePath' => '', 'title', 'desc', 'btnLabel' => '']); ?>
<?php foreach (array_filter((['imgPath' => '', 'routePath' => '', 'title', 'desc', 'btnLabel' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="relative md:h-screen h-full p-5 bg-cover bg-center bg-no-repeat"
    style="background-image: url('<?php echo e("resources/img/$imgPath"); ?>');">
    <!-- Gradient Overlay -->
    <div class="absolute inset-0 bg-gradient-to-r from-[#F57D11] via-[#F57D11]/90 to-[#F53C11] opacity-80">
    </div>

    <!-- Content Section (Ensures text stays above the overlay) -->
    <section class="relative flex flex-col gap-5 items-center justify-center h-full text-white text-center">
        <h1 class="lg:text-4xl sm:text-2xl text-xl font-bold"><?php echo e($title); ?></h1>
        <p class="lg:text-lg md:text-base text-sm"><?php echo e($desc); ?></p>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['secondary' => true,'button' => true,'label' => ''.e($btnLabel).'','routePath' => ''.e($routePath).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['secondary' => true,'button' => true,'label' => ''.e($btnLabel).'','routePath' => ''.e($routePath).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </section>
</div>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/components/form/option.blade.php ENDPATH**/ ?>