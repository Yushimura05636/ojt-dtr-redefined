<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => 'label',
    'labelClass' => '',
    'leftIcon' => '',
    'rightIcon' => '',
    'className' => '',
    'submit' => false,
    'button' => false,
    'routePath' => '',
    'closeModal' => false,
    'openModal' => false,
    'primary' => false,
    'secondary' => false,
    'tertiary' => false,
    'onClick' => '', // New: JavaScript function or event handler
    'name' => '',
    'loading' => false,
    'disabled' => false,
    'showLabel' => false,
    'big' => false,
    'params' => [],
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => 'label',
    'labelClass' => '',
    'leftIcon' => '',
    'rightIcon' => '',
    'className' => '',
    'submit' => false,
    'button' => false,
    'routePath' => '',
    'closeModal' => false,
    'openModal' => false,
    'primary' => false,
    'secondary' => false,
    'tertiary' => false,
    'onClick' => '', // New: JavaScript function or event handler
    'name' => '',
    'loading' => false,
    'disabled' => false,
    'showLabel' => false,
    'big' => false,
    'params' => [],
]); ?>
<?php foreach (array_filter(([
    'label' => 'label',
    'labelClass' => '',
    'leftIcon' => '',
    'rightIcon' => '',
    'className' => '',
    'submit' => false,
    'button' => false,
    'routePath' => '',
    'closeModal' => false,
    'openModal' => false,
    'primary' => false,
    'secondary' => false,
    'tertiary' => false,
    'onClick' => '', // New: JavaScript function or event handler
    'name' => '',
    'loading' => false,
    'disabled' => false,
    'showLabel' => false,
    'big' => false,
    'params' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $primaryClasses =
        'px-16 py-3 rounded-full relative overflow-hidden font-medium text-white flex items-center justify-center gap-2 animate-transition bg-gradient-to-r from-custom-orange via-custom-orange/70 to-custom-red hover:bg-custom-red disabled:opacity-50 lg:text-sm text-xs';
    $secondaryClasses =
        'px-16 py-3 border rounded-full hover:bg-white border-white hover:text-custom-orange animate-transition flex items-center justify-center lg:text-sm text-xs';
    $tertiaryClasses =
        'px-16 py-3 border rounded-full text-custom-orange hover:border-custom-orange animate-transition flex items-center justify-center gap-2 lg:text-sm text-xs';

    // Assign correct classes based on button type
    $buttonClass = $primary ? $primaryClasses : ($secondary ? $secondaryClasses : ($tertiary ? $tertiaryClasses : ''));

?>

<!-- Main Button -->

<button
    class="<?php echo e($className); ?> <?php echo e($buttonClass); ?> <?php if($big): ?> 'py-4 lg:text-lg sm:text-base text-sm' <?php endif; ?>"
    name="<?php echo e($name); ?>"
    <?php if($closeModal): ?> data-pd-overlay="<?php echo e($closeModal); ?>" data-modal-target="<?php echo e($closeModal); ?>" <?php endif; ?>
    <?php if($openModal): ?> data-pd-overlay="# . <?php echo e($openModal); ?>" data-modal-target="<?php echo e($openModal); ?>" data-modal-toggle="<?php echo e($openModal); ?>" <?php endif; ?>
    <?php if($submit): ?> type="submit" <?php elseif($button): ?> type="button" <?php endif; ?>
    <?php if($onClick): ?> onclick="<?php echo e($onClick); ?>" <?php endif; ?>
    <?php if($routePath): ?> onclick="window.location.href='<?php echo e(route($routePath, $params)); ?>'" <?php endif; ?>>

    <?php if($leftIcon): ?>
        <span class="<?php echo e($leftIcon); ?>"></span>
    <?php endif; ?>

    <?php if($showLabel): ?>
        <p class="md:block hidden"><?php echo e($label); ?></p>
    <?php else: ?>
        <p><?php echo e($label); ?></p>
    <?php endif; ?>

    <?php if($rightIcon): ?>
        <span class="<?php echo e($rightIcon); ?>"></span>
    <?php endif; ?>


</button>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/components/button.blade.php ENDPATH**/ ?>