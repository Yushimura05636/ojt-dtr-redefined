



<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.time-in-time-out-modal','data' => ['id' => 'time-in-time-out-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.time-in-time-out-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'time-in-time-out-modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<!-- HTML5 QR Code Scanner -->
<script src="https://unpkg.com/html5-qrcode"></script>

<link rel="stylesheet" href="../resources/css/app.css">
    <script src="../resources/js/app.js"></script>

<link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.4.1/dist/tailwind.min.css" rel="stylesheet">

<!-- Camera -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>

<!-- Include Toastr CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

<!-- Include jQuery (required for Toastr) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Include Toastr JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>




<!-- Check if there is a toast session message -->
<?php if(session('toast')): ?>
    <script>
        // Show the Toastr notification based on the session data
        var toastData = <?php echo json_encode(session('toast'), 15, 512) ?>;

        // Customize the options for Toastr
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "5000", // The message will stay for 5 seconds
        };

        // Display the message
        if (toastData.status == 'success') {
            toastr.success(toastData.message); // Display success toast
        } else if (toastData.status == 'error') {
            toastr.error(toastData.message); // Display error toast
        }
    </script>
<?php endif; ?>


<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => ['arrayDaily' => $array_daily,'ranking' => $ranking]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['array_daily' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($array_daily),'ranking' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ranking)]); ?>

    

    <div class="flex flex-col gap-5 w-auto h-auto">

        <div class="h-full w-full">
            <section class="h-full w-full p-7 border bg-white rounded-xl border-gray-200">
                <!-- Scanner Section -->
                <div id="reader" class="h-full w-full"></div>
            </section>


        </div>

        <div class="flex lg:flex-row flex-col lg:gap-7 gap-5 w-full lg:!h-[500px] h-[600px]">
            <section
                class="p-7 w-full border bg-white border-gray-200 rounded-xl h-full overflow-hidden flex flex-col gap-5">
                <div
                    class="flex lg:items-end items-center flex-wrap gap-2 text-[#F53C11] justify-between w-full font-semibold">
                    <div class="flex lg:items-start items-center gap-2">
                        <span class="material-symbols--co-present-outline"></span>
                        <p class="font-semibold lg:!text-lg text-sm">Daily Attendance</p>
                    </div>

                    <div class="md:!text-sm text-xs font-semibold">
                        <?php echo e(\Carbon\Carbon::now()->format('M d, Y')); ?></div>
                </div>
                <div class="h-full pb-7 w-full bg-white overflow-y-auto border border-gray-100 rounded-md">
                    <?php $__empty_1 = true; $__currentLoopData = $array_daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daily): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('admin.users.details', ['id' => $daily['id']])); ?>"
                            class="px-7 py-5 w-full flex flex-wrap justify-between border-b border-gray-200 bg-white hover:bg-gray-100 items-center cursor-pointer">
                            <div class="flex items-start gap-5 w-full">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['className' => 'w-12 h-12 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['className' => 'w-12 h-12 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <div class="flex items-center flex-wrap justify-between w-full gap-x-2">
                                    <div class="w-1/2 ">
                                        <section class="font-bold text-black text-lg truncate">
                                            <?php echo e($daily['timeFormat']); ?>

                                        </section>
                                        <p class="text-sm font-medium text-gray-700 capitalize truncate">
                                            <?php echo e($daily['name']); ?></p>
                                    </div>
                                    <?php if($daily['description'] === 'time in'): ?>
                                        <div
                                            class="text-green-500 flex items-center gap-1 select-none text-sm font-semibold">

                                            <p>Time in</p>
                                        </div>
                                    <?php else: ?>
                                        <div
                                            class="text-red-500 flex items-center gap-1 select-none text-sm font-semibold">

                                            <p>Time out</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h1 class="text-center flex items-center justify-center h-full font-semibold text-gray-500">
                            Waiting for attendees...
                        </h1>
                    <?php endif; ?>
                </div>
            </section>

            <section
                class="p-7 rounded-xl border border-gray-200 bg-white h-full w-full overflow-hidden flex flex-col gap-5">
                <div
                    class="flex lg:items-end items-center flex-wrap gap-2 text-[#F53C11] justify-between w-full font-semibold">
                    <div class="flex lg:items-start items-center gap-2">
                        <span class="hugeicons--champion"></span>
                        <p class="font-semibold lg:!text-lg text-sm">Top 3 Performer</p>
                    </div>
                    <p class="md:!text-sm text-xs font-semibold">Highest Hour Basis</p>
                </div>

                <!--HTML CODE-->
                <div class="w-full relative h-full">
                    <div class="swiper progress-slide-carousel swiper-container h-full flex">
                        <div class="swiper-wrapper h-full flex">
                            <?php $__empty_1 = true; $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="swiper-slide h-full flex">
                                    <div
                                        class="bg-[#F57D11]/5 h-full w-full overflow-hidden flex flex-col justify-center">
                                        <section class="flex items-end text-center gap-2 w-full p-5 relative h-full">
                                            <div class="w-full space-y-1 px-5">
                                                <p class="text-sm font-semibold">TOP <?php echo e($index + 1); ?></p>
                                                <h1 class="text-sm truncate capitalize text-gray-500/80">
                                                    <?php echo e($user['name']); ?>

                                                </h1>
                                                <p class="text-xl font-semibold text-[#F57D11]">
                                                    <?php echo e($user['hours_worked']); ?> hours
                                                </p>
                                            </div>
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['path' => 'resources/img/default-male.png','className' => 'absolute inset-0 mx-auto h-full scale-125 w-auto opacity-20 z-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['path' => 'resources/img/default-male.png','className' => 'absolute inset-0 mx-auto h-full scale-125 w-auto opacity-20 z-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </section>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="flex w-full items-center justify-center h-full font-semibold text-gray-500">
                                    No top performer yet.
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="swiper-pagination !bottom-0 !top-auto mx-auto bg-gray-100"></div>
                    </div>
                </div>

            </section>
        </div>

        <?php
            $totals = [
                ['label' => 'Total Scans', 'number' => $totalScans],
                ['label' => 'Total Registered', 'number' => $totalRegister],
                ['label' => 'Time In', 'number' => $totalTimeIn],
                ['label' => 'Time Out', 'number' => $totalTimeOut],
            ];
        ?>

        <div class="grid grid-cols-2 gap-5 w-full h-auto">
            <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="p-7 w-full flex justify-between h-full border bg-white border-gray-200 rounded-xl">
                    <h1 class="font-semibold text-sm"><?php echo e($total['label']); ?></h1>
                    <p class="font-bold text-xl text-[#F53C11]"><?php echo e($total['number']); ?></p>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="w-full h-full">
            <section class="p-7 w-full border bg-white border-gray-200 rounded-xl h-[500px] flex flex-col gap-5">
                <div class="flex items-center gap-2 text-[#F53C11] font-semibold">
                    <span class="cuida--user-add-outline"></span>
                    <p class="font-semibold text-lg">Recently Added Users</p>
                </div>
                <div class="h-full w-full bg-white overflow-y-auto border border-gray-100 rounded-md">
                    <?php $__currentLoopData = $recentlyAddedUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.users.details', ['id' => $user['id']])); ?>"
                            class="px-7 py-5 w-full flex justify-between items-center border-b border-gray-200 hover:bg-gray-100 cursor-pointer">
                            <div class="flex items-center gap-5 w-1/2">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['className' => 'w-12 h-12 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['className' => 'w-12 h-12 rounded-full border border-[#F57D11]','path' => 'resources/img/default-male.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <h1 class="font-semibold capitalize truncate"><?php echo e($user['fullname']); ?></h1>
                            </div>
                            <p><?php echo e($user['ago']); ?></p>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-pd-overlay="#time-in-time-out-modal"
                        data-modal-target="time-in-time-out-modal" data-modal-toggle="time-in-time-out-modal"
                        name="showTimeShift" class="hidden modal-button">Scan Successfully!</button>
                </div>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<script>
    let scannerInstance = null; // Store scanner instance globally

    // swiper
    var swiper = new Swiper(".progress-slide-carousel", {
        loop: true,
        fraction: true,
        autoplay: {
            delay: 1200,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".progress-slide-carousel .swiper-pagination",
            type: "progressbar",
        },
    });

    function closeCamera() {
        if (scannerInstance) {
            alert('hello')
            scannerInstance.clear()
                .then(() => {
                    console.log("Scanner stopped");
                    document.getElementById("reader").innerHTML = ""; // Clear the scanner UI
                })
                .catch(err => {
                    console.error("Error stopping scanner:", err);
                });
        }
    }

    // Initialize QR Scanner
    function initScanner() {
        scannerInstance = new Html5QrcodeScanner('reader', {
            qrbox: {
                width: 400,
                height: 400
            },
            fps: 10
        });

        scannerInstance.render(onScanSuccess, onScanError);
    }

    async function onScanSuccess(decodedText) {
        try {
            const response = await axios.get(`/public/scanner/${encodeURIComponent(decodedText)}`);
            console.log(response.data); // Debugging log

            // Open modal
            const modalButton = document.querySelector('[name="showTimeShift"]');
            if (modalButton) {
                modalButton.click();
            } else {
                console.error("Modal button not found!");
            }

            // Get elements
            const nameEmail = document.querySelector('[name="email"]');
            const nameFullname = document.querySelector('[name="fullname"]');
            const nameStudentNo = document.querySelector('[name="student_no"]');
            const namePhone = document.querySelector('[name="phone"]');
            const nameQrCode = document.querySelector('[name="qr_code"]');
            const nameTotalHours = document.querySelector('[name="total_hours"]');
            const nameButtonTimeIn = document.querySelector('[name="button_time_in"]');
            const nameButtonTimeOut = document.querySelector('[name="button_time_out"]');
            const nameLoadingButton = document.querySelector('[name="loading_button"]');

            // Ensure all elements exist
            if (!nameStudentNo || !namePhone || !nameQrCode || !nameTotalHours ||
                !nameButtonTimeIn || !nameButtonTimeOut) {
                console.error("One or more elements were not found in the DOM.");
                return;
            }

            // Assign values
            nameFullname.textContent = response.data.user.firstname + ' ' +
                response.data.user.middlename + ' ' + response.data.user.lastname;
            nameEmail.textContent = response.data.user.email;
            nameStudentNo.textContent = response.data.user.student_no;
            namePhone.textContent = response.data.user.phone;
            nameQrCode.textContent = response.data.user.qr_code;
            nameTotalHours.textContent = "0 Hours";

            // Remove old event listeners
            nameButtonTimeIn.replaceWith(nameButtonTimeIn.cloneNode(true));
            nameButtonTimeOut.replaceWith(nameButtonTimeOut.cloneNode(true));

            // Get the new button references
            const newButtonTimeIn = document.querySelector('[name="button_time_in"]');
            const newButtonTimeOut = document.querySelector('[name="button_time_out"]');


            // Add event listeners
            newButtonTimeIn.addEventListener('click', async function() {
                try {
                    newButtonTimeIn.classList.add('hidden');
                    newButtonTimeOut.classList.add('hidden');
                    nameLoadingButton.classList.remove('hidden');
                    nameLoadingButton.classList.add('block');
                    nameLoadingButton.innerHTML =
                        "<div class='flex justify-center items-center w-full'><span class='line-md--loading-loop'></span><span> Time In </span></div>";
                    const res = await axios.post('/public/history', {
                        qr_code: response.data.user.qr_code,
                        type: 'time_in',
                    });

                    if (res.data.success) {
                        toastr.success("Time In checked successfully");
                    } else {
                        toastr.error("Failed to check Time In");
                    }

                    setTimeout(() => location.reload(true), 2000);
                } catch (error) {
                    console.error("Error in Time In:", error);
                }
            });

            newButtonTimeOut.addEventListener('click', async function() {
                try {
                    newButtonTimeIn.classList.add('hidden');
                    newButtonTimeOut.classList.add('hidden');
                    nameLoadingButton.classList.remove('hidden');
                    nameLoadingButton.classList.add('block');
                    nameLoadingButton.innerHTML =
                        "<div class='flex justify-center items-center w-full'><span class='line-md--loading-loop'></span><span> Time Out </span></div>";

                    const res = await axios.post('/public/history', {
                        qr_code: response.data.user.qr_code,
                        type: 'time_out',
                    });

                    if (res.data.success) {
                        toastr.success("Time Out checked successfully");
                    } else {
                        toastr.error("Failed to check Time Out");
                    }

                    setTimeout(() => location.reload(true), 2000);
                } catch (error) {
                    console.error("Error in Time Out:", error);
                }
            });

        } catch (error) {
            console.error("Error fetching QR data:", error.response ? error.response.data : error.message);
        }
    }


    const onScanError = (errorMessage) => {
        // Ignore the specific "No MultiFormat Readers" error
        if (!errorMessage.includes("No MultiFormat Readers were able to detect the code")) {
            console.error("QR Scan error:", errorMessage);
        }
    };

    function timeIn() {
        console.log('hello');
    }

    //load all functions if the page is loaded
    // Ensure DOM is fully loaded before initializing scanner
    document.addEventListener('DOMContentLoaded', () => {
        //initialize scanner
        initScanner();

        // Attach event listener to close button after DOM is ready
        document.getElementById("closeButton").addEventListener("click", closeCamera);
    });
</script>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>