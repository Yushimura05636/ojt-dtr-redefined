

<p>Hello <?php echo e($user->firstname . ' ' . substr($user->middlename, 0, 1) . '. ' . $user->lastname); ?></p>
<p>Your <?php echo e($history->description); ?> shift has been successfully recorded.</p>
<p>🕒 <?php echo e($history->description); ?>: <?php echo e($history->datetime->format('F j, Y h:i:s A')); ?></p>
<p>If this was not you, please contact HR immediately.</p>
<p>Have a great workday!</p>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/email/email-shift-notification.blade.php ENDPATH**/ ?>