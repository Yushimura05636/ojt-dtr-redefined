<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="h-auto w-full flex flex-col gap-6">
        

        <section
            class="w-full flex items-center justify-between gap-5 bg-white p-3 border border-gray-200 shadow-lg sticky top-[125px] z-30 rounded-full">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['routePath' => 'admin.users','label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['routePath' => 'admin.users','label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <div class="flex items-center gap-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['tertiary' => true,'label' => 'View DTR','routePath' => 'admin.users.dtr','params' => ['id' => $user->id],'button' => true,'className' => 'px-8 font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tertiary' => true,'label' => 'View DTR','routePath' => 'admin.users.dtr','params' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['id' => $user->id]),'button' => true,'className' => 'px-8 font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['primary' => true,'label' => 'Edit User','button' => true,'className' => 'px-8','routePath' => 'admin.users.details.edit','params' => ['id' => $user->id]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => 'Edit User','button' => true,'className' => 'px-8','routePath' => 'admin.users.details.edit','params' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['id' => $user->id])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </section>

        <section class="rounded-lg p-7 border border-gray-200 bg-white h-auto w-full flex flex-col gap-5">

            <div class="w-full">
                <div class="w-auto h-auto flex flex-col gap-3 items-center justify-center mb-5">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['className' => 'lg:!w-80 md:!w-60 w-40 lg:!h-80 md:!h-60 h-40 rounded-full border border-[#F57D11] lg:!mx-0 mx-auto','path' => 'resources/img/default-male.png']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['className' => 'lg:!w-80 md:!w-60 w-40 lg:!h-80 md:!h-60 h-40 rounded-full border border-[#F57D11] lg:!mx-0 mx-auto','path' => 'resources/img/default-male.png']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <h1 class="capitalize font-semibold text-lg"><?php echo e($user->firstname); ?>

                        <?php echo e(substr($user->middlename, 0, 1)); ?>. <?php echo e($user->lastname); ?></h1>
                </div>

                <div class="space-y-2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.section-title','data' => ['title' => 'User Details','vectorClass' => '!h-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'User Details','vectorClass' => '!h-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <section class="flex items-start gap-x-2">
                        <div class="text-sm font-semibold text-gray-700">Gender:</div>
                        <p class="text-base -mt-[3px] capitalize"><?php echo e($user->gender); ?></p>
                    </section>
                    <section class="flex items-start gap-x-2">
                        <div class="text-sm font-semibold text-gray-700">Email:</div>
                        <p class="text-base -mt-[3px]"><?php echo e($user->email); ?></p>
                    </section>
                    <section class="flex items-start gap-x-2">
                        <div class="text-sm font-semibold text-gray-700">Phone No:</div>
                        <p class="text-base -mt-[3px]"><?php echo e($user->phone); ?></p>
                    </section>
                    <section class="flex items-start gap-x-2">
                        <div class="text-sm font-semibold text-gray-600">Address:</div>
                        <p class="text-base -mt-[3px]"><?php echo e($user->address); ?></p>
                    </section>
                    <section class="flex items-start gap-x-2">
                        <div class="text-sm font-semibold text-gray-600">School:</div>
                        <p class="text-base -mt-[3px]"><?php echo e($user->school); ?></p>
                    </section>
                </div>
            </div>

            <hr>

            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.section-title','data' => ['title' => 'Emergency Contact','vectorClass' => '!h-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Emergency Contact','vectorClass' => '!h-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <section class="flex items-start gap-x-2">
                    <div class="text-sm font-semibold text-gray-700">Name:</div>
                    <p class="text-base -mt-[3px]"><?php echo e($user->emergency_contact_fullname); ?></p>
                </section>
                <section class="flex items-start gap-x-2">
                    <div class="text-sm font-semibold text-gray-700">Address:</div>
                    <p class="text-base -mt-[3px]"><?php echo e($user->emergency_contact_address); ?></p>
                </section>
                <section class="flex items-start gap-x-2">
                    <div class="text-sm font-semibold text-gray-700">Contact No:</div>
                    <p class="text-base -mt-[3px]"><?php echo e($user->emergency_contact_number); ?></p>
                </section>
            </div>

            <hr>

            <div class="space-y-2">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.section-title','data' => ['title' => 'Account Status','vectorClass' => '!h-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Account Status','vectorClass' => '!h-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <section class="flex items-start gap-x-2">
                    <div class="text-sm font-semibold text-gray-700">Account Started:</div>
                    <p class="text-base -mt-[3px]"><?php echo e($user->starting_date); ?></p>
                </section>
                <section class="flex items-start gap-x-2">
                    <div class="text-sm font-semibold text-gray-700">Account Expiration:</div>
                    <p class="text-base -mt-[3px]"><?php echo e($user->expiry_date); ?></p>
                </section>
            </div>
        </section>

        <section class="h-auto w-full border border-gray-200 rounded-lg">
            <div
                class="flex items-center gap-1 px-7 py-5 bg-gradient-to-r from-[#F57D11] via-[#F57D11]/90 to-[#F53C11] rounded-t-lg text-white shadow-md w-full">
                <span class="material-symbols--history-rounded w-6 h-6"></span>
                <h1 class="font-semibold">Logged History</h1>
            </div>

            <?php
                // $histories = [
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                //     ['description' => 'time in', 'timeFormat' => '2025-02-05 08:48:35', 'datetime' => '2025-02-05'],
                // ];
            ?>

            <div class="h-60 w-full bg-white overflow-auto rounded-b-lg">
                <div class="text-black flex flex-col h-full items-start justify-start">
                    <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <section
                            class="px-7 py-5 w-full h-fit border-b border-gray-200 hover:bg-gray-100 flex flex-wrap gap-2 justify-between items-center">
                            <div>
                                <section class="font-bold"><?php echo e($history['timeFormat'] ?? 'N/A'); ?></section>
                                <p class="text-sm font-medium text-gray-700">
                                    <?php echo e($history['datetime'] ?? 'No date available'); ?>

                                </p>
                            </div>
                            <?php if(!empty($history['description']) && $history['description'] === 'time in'): ?>
                                <div class="text-green-500 flex items-center gap-1 select-none text-sm font-semibold">
                                    <p>Time in</p>
                                </div>
                            <?php else: ?>
                                <div class="text-red-500 flex items-center gap-1 select-none text-sm font-semibold">
                                    <p>Time out</p>
                                </div>
                            <?php endif; ?>
                        </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class=" h-full w-full flex items-center justify-center ">
                            <p class="text-center font-semibold text-gray-600">
                                User has no logged history.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\infi-deployment\resources\views/admin/users/show.blade.php ENDPATH**/ ?>