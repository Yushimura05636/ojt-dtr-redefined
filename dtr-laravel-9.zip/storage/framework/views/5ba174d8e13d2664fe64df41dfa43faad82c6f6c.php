<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <main class="w-full">
        
        <div class="flex flex-col gap-5 w-full items-center justify-center pb-5">
            <div
                class="w-full grid grid-cols-2 text-nowrap gap-5 bg-white p-3 border border-gray-200 shadow-lg sticky top-5 z-30 rounded-full max-w-screen-xl mx-auto">

                <section class="col-span-1 flex items-center justify-start">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['routePath' => 'users.request','label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['routePath' => 'users.request','label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </section>

                <section class="flex items-center gap-3 col-span-1 justify-end w-full h-auto capitalize px-10">
                    <?php if($status === 'approved'): ?>
                        <span class="text-green-500 font-semibold text-sm">
                            Ready to Download
                        </span>
                        <button class="px-2 py-1 rounded-md bg-green-500 text-white" onclick="window.location.href=`/request/<?php echo e($id); ?>?type=download`">
                            <span class="material-symbols--download-rounded !w-6 !h-6"></span>
                        </button>
                    <?php elseif($status === 'declined'): ?>
                        <span class="text-red-500 font-semibold text-sm">
                            Declined
                        </span>
                    <?php else: ?>
                        <span class="text-blue-500 font-semibold text-sm">
                            Waiting for approval..
                        </span>
                    <?php endif; ?>

                    
                </section>
            </div>

            <div class="xl:w-[75%] lg:w-[85%] md:w-[95%] w-[100%] h-auto mt-8 border <?php if($declined_by): ?> border-red-300 
            <?php endif; ?> <?php if($approved_by): ?>
                border-green-300
            <?php else: ?> border-blue-300
            <?php endif; ?> ">
                <div
                    class="w-auto h-auto border bg-white border-gray-100 shadow-md resize-none p-8 space-y-5 select-none">
                    <section class="flex items-start justify-between">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['width' => 'lg:w-[200px] w-[150px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => 'lg:w-[200px] w-[150px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </section>
                    <section class="my-7 text-center">
                        <p class="text-[#F57D11] font-semibold sm:text-base text-sm">OJT Daily Time Record</p>
                        <h1 class="lg:text-xl sm:text-lg text-base md:mt-2 font-bold">
                            <?php echo e($pagination['currentMonth']['name']); ?></h1>
                    </section>
                    <hr>
                    <section class="sm:space-y-2">
                        <p class="lg:text-sm text-xs font-semibold">Name: <span
                                class="font-normal lg:text-base text-sm capitalize"><?php echo e($user->firstname); ?>

                                <?php echo e($user->middlename); ?>

                                <?php echo e($user->lastname); ?></span></p>
                        <p class="lg:text-sm text-xs font-semibold">Position: <span
                                class="font-normal lg:text-base text-sm">Intern</span>
                        </p>
                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <p class="lg:text-sm text-xs font-semibold">Total Time This Month: <span
                                    class="font-normal lg:text-base text-sm"><?php echo e(floor((int) filter_var($totalHoursPerMonth, FILTER_SANITIZE_NUMBER_INT) / 60)); ?>

                                    hours
                                    <?php echo e(round((int) filter_var($totalHoursPerMonth, FILTER_SANITIZE_NUMBER_INT) % 60)); ?>

                                    minutes</span></p>
                                    <?php if($approved_by === null || !isset($approved_by)): ?>
                                        <?php if($declined_by != null || isset($declined_by)): ?>
                                            <p class="lg:text-sm text-xs font-semibold text-red-500">Declined by: 
                                                <span
                                                class="font-normal lg:text-base text-sm capitalize"><?php echo e($declined_by); ?></span>
                                            </p>
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <p class="lg:text-sm text-xs font-semibold">Approved by: 
                                            <span
                                            class="font-normal lg:text-base text-sm capitalize"><?php echo e($approved_by); ?></span>
                                        </p>
                                    <?php endif; ?>
                        </div>
                    </section>

                    <input type="text" name='monthValue' class="hidden"
                        value="<?php echo e($pagination['currentMonth']['month']); ?>" />
                    <input type="text" name='yearValue' class="hidden"
                        value="<?php echo e($pagination['currentMonth']['year']); ?>" />

                    <section class="h-auto w-full border border-gray-200 overflow-x-auto">
                        <table class="w-full border-collapse border border-gray-300">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                        Day
                                    </th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                        Time In</th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                        Time Out
                                    </th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                        Total Time
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($records) && count($records) > 0): ?>
                                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e(\Carbon\Carbon::parse($data['date'])->format(' j')); ?></td>
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e($data['time_in']); ?></td>
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e($data['time_out']); ?>

                                            </td>
                                            <?php if($data['hours_worked'] == '—'): ?>
                                                <td
                                                    class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                    —
                                                </td>
                                            <?php else: ?>
                                                <?php if((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) / 60 < 1): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        <?php echo e((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT)); ?>

                                                        minutes
                                                    </td>
                                                <?php elseif((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) / 60 == 1): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        <?php echo e((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) / 60); ?>

                                                        hour</td>
                                                <?php elseif((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) / 60 > 1): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        <?php echo e(floor((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) / 60)); ?>

                                                        hours
                                                        <?php echo e(round((int) filter_var($data['hours_worked'], FILTER_SANITIZE_NUMBER_INT) % 60)); ?>

                                                        minutes
                                                    </td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="text-center">
                                        <td colspan="4"
                                            class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                            No records
                                            found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </section>

                </div>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\infi-deployment\resources\views/users/request/show.blade.php ENDPATH**/ ?>