<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'label' => false,
    'type' => 'text',
    'name_id',
    'value' => '',
    'placeholder' => '',
    'labelClass' => '',
    'small' => false,
    'big' => false,
    'hidden' => false,
    'options' => [], // Dropdown options
    'disabled' => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'label' => false,
    'type' => 'text',
    'name_id',
    'value' => '',
    'placeholder' => '',
    'labelClass' => '',
    'small' => false,
    'big' => false,
    'hidden' => false,
    'options' => [], // Dropdown options
    'disabled' => false,
]); ?>
<?php foreach (array_filter(([
    'label' => false,
    'type' => 'text',
    'name_id',
    'value' => '',
    'placeholder' => '',
    'labelClass' => '',
    'small' => false,
    'big' => false,
    'hidden' => false,
    'options' => [], // Dropdown options
    'disabled' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="space-y-3">
    <?php if($label): ?>
        <label for="<?php echo e($name_id); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            '<?php echo e($labelClass); ?> lg:text-base text-sm font-semibold text-gray-700',
            'border-[#F53C11]' => $errors->has($name_id),
        ]) ?>"><?php echo e($label); ?></label>
    <?php endif; ?>

    <?php if($type === 'select'): ?>
        <!-- Dropdown Selection -->
        <select id="<?php echo e($name_id); ?>" name="<?php echo e($name_id); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            'border w-full tracking-wider focus:ring-2 focus:ring-[#F57D11] focus:outline-none bg-white',
            'border-[#F53C11]' => $errors->has($name_id),
            'px-4 py-2 rounded-lg' => $small,
            'px-5 py-4 rounded-xl' => $big,
            'hidden' => $hidden,
            'opacity-50 cursor-not-allowed bg-gray-100' => $disabled,
        ]) ?>"
            <?php if($disabled): ?> disabled aria-disabled="true" tabindex="-1" <?php endif; ?>>
            <option value="" disabled selected><?php echo e($placeholder); ?></option>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php echo e(old($name_id, $value) == $key ? 'selected' : ''); ?>>
                    <?php echo e($option); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <!-- Normal Input Field -->
        <input type="<?php echo e($type); ?>" id="<?php echo e($name_id); ?>" name="<?php echo e($name_id); ?>"
            value="<?php echo e(old($name_id, $value)); ?>" placeholder="<?php echo e($placeholder); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'border w-full tracking-wider focus:ring-2 focus:ring-[#F57D11] focus:outline-none lg:text-base text-sm',
                'border-[#F53C11]' => $errors->has($name_id),
                'px-4 py-2 rounded-lg' => $small,
                'px-5 py-4 rounded-xl' => $big,
                'hidden' => $hidden,
                'opacity-50 cursor-not-allowed bg-gray-100' => $disabled,
            ]) ?>"
            <?php if($disabled): ?> disabled aria-disabled="true" tabindex="-1" <?php endif; ?>>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.error','data' => ['name' => ''.e($name_id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name_id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/components/form/input.blade.php ENDPATH**/ ?>