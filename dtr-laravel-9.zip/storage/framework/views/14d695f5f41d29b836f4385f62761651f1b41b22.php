<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <main class="flex flex-col gap-5">
        <section
            class="w-full flex items-center justify-between gap-5 bg-white p-3 border border-gray-200 shadow-lg sticky top-[125px] z-30 rounded-full">
            <section class="lg:col-span-1 flex justify-start items-center">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['routePath' => 'admin.users.details','params' => ['id' => $user->id],'label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['routePath' => 'admin.users.details','params' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['id' => $user->id]),'label' => 'Back','tertiary' => true,'button' => true,'showLabel' => ''.e(true).'','leftIcon' => 'eva--arrow-back-fill','className' => 'lg:px-8 px-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </section>
            <div class="flex items-center justify-end lg:col-span-1 gap-3">
                <form action="<?php echo e(route('admin.users.dtr.post', ['id' => $user->id])); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <input type="month" name="searchDate" id="searchDate"
                        class="px-5 py-2 rounded-full cursor-pointer border border-gray-200 text-sm"
                        value="<?php echo e(\Carbon\Carbon::parse($pagination['currentMonth']['name'])->format('Y-m')); ?>"
                        onchange="this.form.submit()">
                </form>
                <form
                    action="<?php echo e(route('download.pdf', ['records' => $records, 'pagination' => $pagination, 'totalHoursPerMonth' => $totalHoursPerMonth])); ?>"
                    method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['primary' => true,'label' => 'Download PDF','showLabel' => ''.e(true).'','leftIcon' => 'material-symbols--download-rounded','submit' => true,'className' => 'text-xs lg:px-8 px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => 'Download PDF','showLabel' => ''.e(true).'','leftIcon' => 'material-symbols--download-rounded','submit' => true,'className' => 'text-xs lg:px-8 px-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </form>
            </div>
        </section>



        <section class="w-full h-auto overflow-auto space-y-7">
            
            <div class="flex w-full items-center justify-center">
                <div class="w-full h-auto">
                    <div
                        class="w-auto h-auto border bg-white border-gray-100 shadow-md resize-none p-8 space-y-5 select-none">
                        <section class="flex items-start justify-between">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['width' => 'lg:w-[200px] w-[150px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => 'lg:w-[200px] w-[150px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </section>
                        <section class="my-7 text-center">
                            <p class="text-[#F57D11] font-semibold sm:text-base text-sm">OJT Daily Time Record</p>
                            <h1 class="lg:text-xl sm:text-lg text-base md:mt-2 font-bold">
                                <?php echo e($pagination['currentMonth']['name']); ?></h1>
                        </section>
                        <hr>
                        <section class="sm:space-y-2">
                            <p class="lg:text-sm text-xs font-semibold">Name: <span
                                    class="font-normal lg:text-base text-sm capitalize"><?php echo e($user->firstname); ?>

                                    <?php echo e(substr($user->middlename, 0, 1)); ?>. <?php echo e($user->lastname); ?></span></p>
                            <p class="lg:text-sm text-xs font-semibold">Position: <span
                                    class="font-normal lg:text-base text-sm">Intern</span>
                            </p>
                            <div class="flex items-center justify-between gap-3">
                                <p class="lg:text-sm text-xs font-semibold">Hours This Month: <span
                                        class="font-normal lg:text-base text-sm"><?php echo e($totalHoursPerMonth); ?>

                                        Hours</span></p>
                            </div>
                        </section>

                        <section class="h-auto w-full border border-gray-200 overflow-x-auto">
                            <table class="w-full border-collapse border border-gray-300">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th
                                            class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                            Day
                                        </th>
                                        <th
                                            class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                            Time In</th>
                                        <th
                                            class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                            Time Out
                                        </th>
                                        <th
                                            class="border lg:text-sm sm:text-xs text-[10px] text-white bg-[#F57D11] border-[#F57D11]/80 px-4 py-2">
                                            Total Hours
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($records) && count($records) > 0): ?>
                                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td
                                                    class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                    <?php echo e(\Carbon\Carbon::parse($data['date'])->format(' j')); ?></td>
                                                <td
                                                    class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                    <?php echo e($data['time_in']); ?></td>
                                                <td
                                                    class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                    <?php echo e($data['time_out']); ?>

                                                </td>
                                                <?php if($data['hours_worked'] == '—'): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        —
                                                    </td>
                                                <?php else: ?>
                                                    <?php if($data['hours_worked'] <= 0): ?>
                                                        <td
                                                            class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                            Less than 1 hour
                                                        </td>
                                                    <?php elseif($data['hours_worked'] <= 1): ?>
                                                        <td
                                                            class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                            <?php echo e($data['hours_worked']); ?> hour</td>
                                                    <?php elseif($data['hours_worked'] > 1): ?>
                                                        <td
                                                            class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                            <?php echo e($data['hours_worked']); ?> hours</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr class="text-center">
                                            <td colspan="4"
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                No records
                                                found
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </section>

                    </div>
                </div>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/admin/users/dtr.blade.php ENDPATH**/ ?>