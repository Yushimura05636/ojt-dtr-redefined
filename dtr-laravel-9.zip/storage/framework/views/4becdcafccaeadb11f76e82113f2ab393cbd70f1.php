<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.dtr-summary','data' => ['id' => 'dtr-summary-modal','yearlyTotals' => $yearlyTotals]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.dtr-summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dtr-summary-modal','yearlyTotals' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($yearlyTotals)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <main class="w-full">
        
        <div class="flex flex-col gap-5 w-full items-center justify-center pb-5">
            <div
                class="w-full grid xl:!grid-cols-3 text-nowrap grid-cols-2 gap-5 bg-white p-3 border border-gray-200 shadow-lg sticky top-5 z-30 rounded-full max-w-screen-xl mx-auto">

                <section class="xl:col-span-1 xl:flex justify-start items-center hidden w-full">
                    <form action="<?php echo e(route('users.dtr.post')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="month" name="searchDate" id="searchDate"
                            class="px-5 py-2 rounded-full cursor-pointer border border-gray-200 text-sm"
                            value="<?php echo e(\Carbon\Carbon::parse($pagination['currentMonth']['name'])->format('Y-m')); ?>"
                            onchange="this.form.submit()">
                    </form>
                </section>

                <section class="flex items-center gap-3 col-span-1 xl:!justify-center justify-start w-full">
                    <form action="<?php echo e(route('users.dtr.post')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="month" value="<?php echo e($pagination['previousMonth']['month']); ?>">
                        <input type="hidden" name="year" value="<?php echo e($pagination['previousMonth']['year']); ?>">
                        <button type="submit"
                            class="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center text-sm">
                            <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 19l-7-7 7-7" />
                            </svg>
                            <span
                                class="sm:block hidden"><?php echo e(\Carbon\Carbon::parse($pagination['previousMonth']['name'])->format('M Y')); ?></span>
                        </button>
                    </form>
                    <form action="<?php echo e(route('users.dtr.post')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <input type="hidden" name="month" value="<?php echo e($pagination['nextMonth']['month']); ?>">
                        <input type="hidden" name="year" value="<?php echo e($pagination['nextMonth']['year']); ?>">
                        <button type="submit"
                            class="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center text-sm">
                            <span
                                class="sm:block hidden"><?php echo e(\Carbon\Carbon::parse($pagination['nextMonth']['name'])->format('M Y')); ?></span>
                            <svg class="w-5 h-5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </form>
                </section>

                <section class="flex items-center gap-3 col-span-1 justify-end w-full h-auto">
                    <!-- Fix alignment and padding for DTR Summary -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['tertiary' => true,'label' => 'DTR Summary','openModal' => 'dtr-summary-modal','className' => 'text-xs lg:px-8 px-4 modal-button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tertiary' => true,'label' => 'DTR Summary','openModal' => 'dtr-summary-modal','className' => 'text-xs lg:px-8 px-4 modal-button']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                
                    <!-- Request PDF Button (With onClick Event) -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['primary' => true,'label' => 'Request a PDF','showLabel' => ''.e(true).'','leftIcon' => 'ph--hand-deposit','className' => 'text-xs lg:px-8 px-4','onClick' => 'requestPDF()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['primary' => true,'label' => 'Request a PDF','showLabel' => ''.e(true).'','leftIcon' => 'ph--hand-deposit','className' => 'text-xs lg:px-8 px-4','onClick' => 'requestPDF()']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </section>
            </div>

            <div class="xl:w-[75%] lg:w-[85%] md:w-[95%] w-[100%] h-auto mt-8">
                <div
                    class="w-auto h-auto border bg-white border-gray-100 shadow-md resize-none p-8 space-y-5 select-none">
                    <section class="flex items-start justify-between">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['width' => 'lg:w-[200px] w-[150px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => 'lg:w-[200px] w-[150px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image','data' => ['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['path' => 'resources/img/school-logo/sti.png','className' => 'lg:w-16 w-12 h-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </section>
                    <section class="my-7 text-center">
                        <p class="text-custom-orange font-semibold sm:text-base text-sm">OJT Daily Time Record</p>
                        <h1 class="lg:text-xl sm:text-lg text-base md:mt-2 font-bold">
                            <?php echo e($pagination['currentMonth']['name']); ?></h1>
                    </section>
                    <hr>
                    <section class="sm:space-y-2">
                        <p class="lg:text-sm text-xs font-semibold">Name: <span
                                class="font-normal lg:text-base text-sm capitalize"><?php echo e($user->firstname); ?>

                                <?php echo e($user->middlename); ?>

                                <?php echo e($user->lastname); ?></span></p>
                        <p class="lg:text-sm text-xs font-semibold">Position: <span
                                class="font-normal lg:text-base text-sm">Intern</span>
                        </p>
                        <div class="flex items-center justify-between gap-3">
                            <p class="lg:text-sm text-xs font-semibold">Hours This Month: <span
                                    class="font-normal lg:text-base text-sm"><?php echo e($totalHoursPerMonth); ?>

                                    Hours</span></p>
                        </div>
                    </section>

                    <input type="text" name='monthValue' class="hidden" value="<?php echo e($pagination['currentMonth']['month']); ?>" />
                    <input type="text" name='yearValue' class="hidden" value="<?php echo e($pagination['currentMonth']['year']); ?>" />

                    <section class="h-auto w-full border border-gray-200 overflow-x-auto">
                        <table class="w-full border-collapse border border-gray-300">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-custom-orange border-custom-orange/80 px-4 py-2">
                                        Day
                                    </th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-custom-orange border-custom-orange/80 px-4 py-2">
                                        Time In</th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-custom-orange border-custom-orange/80 px-4 py-2">
                                        Time Out
                                    </th>
                                    <th
                                        class="border lg:text-sm sm:text-xs text-[10px] text-white bg-custom-orange border-custom-orange/80 px-4 py-2">
                                        Total Hours
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($records) && count($records) > 0): ?>
                                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e(\Carbon\Carbon::parse($data['date'])->format(' j')); ?></td>
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e($data['time_in']); ?></td>
                                            <td
                                                class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                <?php echo e($data['time_out']); ?>

                                            </td>
                                            <?php if($data['hours_worked'] == '—'): ?>
                                                <td
                                                    class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                    —
                                                </td>
                                            <?php else: ?>
                                                <?php if($data['hours_worked'] <= 0): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        Less than 1 hour
                                                    </td>
                                                <?php elseif($data['hours_worked'] <= 1): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        <?php echo e($data['hours_worked']); ?> hour</td>
                                                <?php elseif($data['hours_worked'] > 1): ?>
                                                    <td
                                                        class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                                        <?php echo e($data['hours_worked']); ?> hours</td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="text-center">
                                        <td colspan="4"
                                            class="border border-gray-300 px-4 py-2 lg:text-base sm:text-sm text-[10px]">
                                            No records
                                            found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </section>

                </div>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<script>

    let month = document.querySelector("[name='monthValue']").value;
    let year = document.querySelector("[name='yearValue']").value;

    console.log(month, year);

    function requestPDF() {

        var user_id = "<?php echo e(auth()->id()); ?>"; // Get logged-in user's ID

        fetch("<?php echo e(route('user.send.request.download.notification')); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>" // CSRF protection
            },
            body: JSON.stringify({
                to_user_id: 1,
                month: month,
                year: year,
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("PDF request successful!");
            } else {
                alert("Failed to generate PDF.");
            }
        })
        .catch(error => console.error("Error:", error));
    }
</script><?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/users/dtr.blade.php ENDPATH**/ ?>