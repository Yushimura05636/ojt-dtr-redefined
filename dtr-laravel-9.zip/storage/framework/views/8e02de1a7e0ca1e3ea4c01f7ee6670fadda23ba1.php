<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['msg']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['msg']); ?>
<?php foreach (array_filter((['msg']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if(session($msg) || $errors->has($msg)): ?>
    <span class="flex items-center justify-center">
        <div id="flash-message-container" class="fixed top-16 z-[60] transform scale-50 opacity-0 animate-popup">
            <p
                class="w-[400px] h-auto py-5 px-5 text-center rounded text-white <?php echo e($msg == 'success' ? 'bg-green-500' : ($msg == 'update' ? 'bg-blue-500' : 'bg-[#F53C11]')); ?>">
                <?php echo e(session($msg) ?? $errors->first($msg)); ?>

            </p>
        </div>
    </span>
<?php endif; ?>

<script>
    window.onload = function() {
        const flashMessageContainer = document.getElementById('flash-message-container');
        if (flashMessageContainer) {
            setTimeout(() => {
                flashMessageContainer.classList.remove('animate-popup');
                flashMessageContainer.classList.add('animate-popdown');
            }, 2500);
        }
    };
</script>

<style>
    @keyframes popup {
        0% {
            transform: scale(0.5);
            opacity: 0;
        }

        50% {
            transform: scale(1.05);
            opacity: 1;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    @keyframes popdown {
        0% {
            transform: scale(1);
            opacity: 1;
        }

        50% {
            transform: scale(0.95);
            opacity: 0.8;
        }

        100% {
            transform: scale(0.5) translateY(20px);
            opacity: 0;
        }
    }

    .animate-popup {
        animation: popup 0.5s ease-out forwards;
    }

    .animate-popdown {
        animation: popdown 0.5s ease-in forwards;
    }
</style>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\infi-deployment\resources\views/components/modal/flash-msg.blade.php ENDPATH**/ ?>