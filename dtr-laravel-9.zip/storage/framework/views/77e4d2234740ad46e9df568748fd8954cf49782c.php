<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id' => '']); ?>
<?php foreach (array_filter((['id' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div id="<?php echo e($id); ?>" class="pd-overlay hidden z-50">
    <div
        class="w-full h-full fixed top-0 left-0 z-[100] flex items-center justify-center  overflow-x-hidden overflow-y-auto bg-black bg-opacity-70">
        <div
            class="w-auto flex items-center justify-center p-10 transition-all ease-out opacity-0 sm:mx-auto modal-open:opacity-100 modal-open:duration-500">
            <div class="flex flex-col px-10 py-5 gap-5 bg-white rounded-2xl">
                <div class="flex items-center justify-between">
                    <h4 class="font-semibold text-gray-900">YOUR PERSONAL QR CODE</h4>
                    <button class="block cursor-pointer close-modal-button" data-pd-overlay="#qr-code-modal"
                        data-modal-target="qr-code-modal">
                        <span class="gg--close-o cursor-pointer hover:text-custom-red text-gray-600"></span>
                    </button>
                </div>
                <div class="w-full h-auto space-y-5 flex flex-col items-center justify-center">
                    <div id="qr-code-container"
                        class="lg:h-auto md:h-98 md:w-98 h-60 w-60 lg:w-auto p-5 overflow-hidden object-center flex items-center justify-center border bg-white rounded-xl border-black">
                        
                        <div id="large-qr-code-img" class="lg:w-[600px] lg:h-[600px] w-52 h-52 m-auto"></div>
                    </div>
                    <p class="text-sm">
                        <span class="font-bold">QR CODE:</span> <span id="qr-code-text">N/A</span>
                    </p>
                    
                    <button label="download QR" id="download-qr-large-btn"
                        class='px-16 py-3 border rounded-full text-custom-orange hover:border-custom-orange animate-transition flex items-center justify-center gap-2'>
                        <i class="material-symbols--download-rounded">download</i>
                        Download QR
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>



<script>
    document.addEventListener("DOMContentLoaded", function() {

        // Add event listener to download QR image
        document.getElementById("download-qr-large-btn").addEventListener("click", function() {

            const qrCanvas = document.getElementById("large-qr-code-img").querySelector("canvas");
            if (qrCanvas) {

                // Get the image data URL (base64 format)
                const qrImage = qrCanvas.toDataURL("image/png");

                // Create an <a> tag dynamically for downloading the image
                const downloadLink = document.createElement("a");
                downloadLink.href = qrImage;
                downloadLink.download = "QR_Code.png"; // Set the default filename for download
                document.body.appendChild(downloadLink);
                downloadLink.click(); // Trigger the download
                document.body.removeChild(
                    downloadLink); // Clean up the link after triggering the download
            } else {
                console.error("QR code not found in the container!");
            }
        });
    });
</script>
<?php /**PATH C:\Users\Admin\Videos\ojt-dtr-laravel-9\convert-to-laravel-9\resources\views/components/modal/qr-code.blade.php ENDPATH**/ ?>