
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="w-full pb-5">
        <h1 class="lg:!text-2xl md:text-lg text-base mb-5 font-semibold">Requests (<?php echo e(count($downloadRequest)); ?>)</h1>

        <!-- Tabs & Search Bar -->
        <div class="flex lg:!flex-row flex-col justify-between gap-5 items-center">

            <!-- Search Input -->
            <div class="lg:!w-1/2 w-full">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input','data' => ['type' => 'text','nameId' => 'search','placeholder' => 'Search','small' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name_id' => 'search','placeholder' => 'Search','small' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>

            <div class="flex">
                <?php
                    $tabs = [
                        'all' => 'All',
                        'pending' => 'Pending',
                        'approved' => 'Approved',
                        'declined' => 'Declined',
                    ];
                    $activeTab = request('status', 'all');
                ?>

                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="?status=<?php echo e($key); ?>"
                        class="px-4 py-2 <?php echo e($activeTab === $key ? 'border-b-2 border-[#F57D11] text-[#F57D11] font-semibold' : 'text-gray-500 hover:text-black'); ?>">
                        <?php echo e($label); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto bg-white shadow-md rounded-lg mt-5">
            <table id="recordsTable" class="w-full border-collapse border border-gray-300">
                <thead>
                    <tr class="*:px-6 *:py-3 *:text-left *:text-sm *:font-semibold *:bg-[#F57D11] *:text-white">
                        <th>#</th>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Date Requested</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        $requests = [];

                        // Generate the request data
                        foreach (range(1, 15) as $i) {
                            $statuses = [
                                'pending' => 'Waiting for approval',
                                'approved' => 'Ready to download',
                                'declined' => 'Declined',
                            ];
                            $statusKey = array_rand($statuses);
                            $requests[] = [
                                'title' => 'Request for DTR Approval',
                                'statusKey' => $statusKey,
                                'statusText' => $statuses[$statusKey],
                                'statusColor' =>
                                    $statusKey === 'approved'
                                        ? 'text-green-500'
                                        : ($statusKey === 'pending'
                                            ? 'text-blue-500'
                                            : 'text-red-500'),
                                'date' => strtotime('2025-02-' . (20 - $i)), // Convert date to timestamp for sorting
                                'formattedDate' => 'Feb ' . (20 - $i) . ', 2025', // Display format
                            ];
                        }

                        // Sort the requests by date (latest first)
                        usort($requests, fn($a, $b) => $b['date'] <=> $a['date']);

                        $rowNumber = 1; // Initialize numbering
                    ?>

                    <?php $__currentLoopData = $downloadRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($activeTab === 'all' || $activeTab === $request['statusKey']): ?>
                            <tr class="border hover:bg-gray-100 *:px-6 *:py-4">
                                <td class="font-semibold text-gray-700"><?php echo e($rowNumber++); ?></td>
                                <!-- Sequential numbering for each tab -->
                                <td><?php echo e($request['title']); ?></td>
                                <td class="font-semibold <?php echo e($request['statusColor']); ?>"><?php echo e($request['statusText']); ?>

                                </td>
                                <td><?php echo e($request['formattedDate']); ?></td>
                                <td class="flex items-center gap-2">
                                    <!-- View Button -->
                                    <div class="relative group">
                                        <button
                                            class="px-2 py-1 bg-blue-500 text-white rounded flex items-center gap-1"
                                            onclick="viewRequest(<?php echo e($request['id']); ?>, <?php echo e($request['month']); ?>, <?php echo e($request['year']); ?>)">
                                            <span class="basil--eye-solid w-6 h-6"></span>
                                        </button>
                                        <span
                                            class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs text-white bg-gray-800 rounded opacity-0 group-hover:opacity-100 transition">
                                            View
                                        </span>
                                    </div>

                                    <!-- Download Button (Only if Approved) -->
                                    <?php if($request['statusKey'] === 'approved'): ?>
                                        <div class="relative group">
                                            <button 
                                                class="px-2 py-1 bg-green-500 text-white rounded flex items-center gap-1"
                                                onclick="downloadRequest(<?php echo e($request['id']); ?>, <?php echo e($request['month']); ?>, <?php echo e($request['year']); ?>)">
                                                <span class="material-symbols--download-rounded w-6 h-6"></span>
                                            </button>
                                            <span
                                                class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 text-xs text-white bg-gray-800 rounded opacity-0 group-hover:opacity-100 transition">
                                                Download
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>

        <p class="mt-5">No pagination yet.</p>
    </div>

    <!-- JavaScript for Search Filtering -->
    <script>
        document.getElementById('search').addEventListener('input', function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll('#recordsTable tbody tr');

            rows.forEach(row => {
                let title = row.children[1].textContent.toLowerCase();
                let status = row.children[2].textContent.toLowerCase();
                let date = row.children[3].textContent.toLowerCase();

                let textContent = title + " " + status + " " + date; // Combine all searchable fields

                row.style.display = textContent.includes(filter) ? '' : 'none';
            });
        });

        function viewRequest(requestId, month, year) {
            window.location.href = `/public/dtr-view/${requestId}?month=${month}&year=${year}&type=view`;
        }


        function downloadRequest(requestId, month, year) {
            window.location.href = `/public/dtr-view/${requestId}?month=${month}&year=${year}&type=download`;
        }

    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/users/request.blade.php ENDPATH**/ ?>