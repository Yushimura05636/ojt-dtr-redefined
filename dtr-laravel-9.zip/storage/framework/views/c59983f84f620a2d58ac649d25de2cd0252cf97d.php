<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.qr-code','data' => ['id' => 'qr-code-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.qr-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'qr-code-modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <main class="w-full flex flex-col gap-5 pb-5">
        <div class="flex md:flex-row flex-col gap-7 md:!h-[350px] !h-full w-full">
            <section class="w-full h-full">
                <div
                    class="flex items-center justify-center gap-2 bg-gradient-to-r from-[#F57D11] via-[#F57D11]/90 to-[#F53C11] px-3 py-2 rounded-t-lg text-white h-fit">
                    <span class="fluent--scan-qr-code-24-filled"></span>
                    <h1 class="font-semibold">Total Scans</h1>
                    <p class="px-2 py-1 rounded-md border font-semibold bg-white text-[#F53C11]">
                        <?php echo e($totalScan); ?>

                    </p>
                </div>
                <div
                    class="p-5 rounded-b-lg border border-gray-200 bg-white w-full h-full text-center gap-3 flex flex-col items-center justify-center">
                    <h1 class="text-sm font-semibold">YOUR PERSONAL QR CODE</h1>
                    <!-- Button with QR Code -->
                    <span hidden id="hidden-data-qr-text"><?php echo e($user->qr_code); ?></span>
                    <button data-modal-target="qr-code-modal" data-qr-text="<?php echo e($user->qr_code); ?>"
                        class="modal-button h-40 w-40 p-5 overflow-hidden flex items-center justify-center border bg-white rounded-xl border-black cursor-pointer">
                        <!-- Small QR Code -->
                        <div id="small-qr-code-img"></div>
                    </button>
                    <p class="text-xs font-medium">Click QR to enlarge</p>
                    <button
                        class='py-3 border rounded-full text-[#F57D11] hover:border-[#F57D11] animate-transition flex items-center justify-center gap-2
                                            text-sm px-8'
                        id="download-qr-small-btn">
                        <span class="material-symbols--download-rounded">download</span>
                        Download QR
                    </button>
                </div>
            </section>

            <section class="h-full w-full border border-gray-200 rounded-lg">
                <div
                    class="flex items-center justify-center gap-1 px-7 py-3 bg-gradient-to-r from-[#F57D11] via-[#F57D11]/90 to-[#F53C11] rounded-t-lg text-white shadow-md w-full border border-[#F57D11]">
                    <span class="material-symbols--history-rounded w-6 h-6"></span>
                    <h1 class="font-semibold">Logged History</h1>
                </div>
                <div class="md:!h-full !h-60 w-full bg-white overflow-auto rounded-b-lg border">
                    <div class=" text-black flex flex-col items-start justify-start">
                        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <section
                                class="px-7 py-5 w-full flex justify-between items-center border-b border-gray-200">
                                <div class="">
                                    <section class="font-bold text-lg"><?php echo e($history['timeFormat']); ?>

                                    </section>
                                    <p class="text-sm font-medium text-gray-700">
                                        <?php echo e($history['datetime']); ?></p>
                                </div>
                                <?php if($history['description'] === 'time in'): ?>
                                    <div
                                        class="text-green-500 flex items-center gap-1 select-none text-sm font-semibold">
                                        <p>Time in</p>
                                    </div>
                                <?php else: ?>
                                    <div class="text-red-500 flex items-center gap-1 select-none text-sm font-semibold">
                                        <p>Time out</p>
                                    </div>
                                <?php endif; ?>
                            </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>

        <div class="flex md:flex-row flex-col gap-7 h-auto w-full md:!mt-14 mt-0">

            <section class="p-7 rounded-lg border border-gray-200 bg-white w-full flex flex-col gap-3">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['title' => 'Additional Information']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Additional Information']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <hr>
                <div class="space-y-2">
                    <section class="flex md:flex-row flex-col items-start flex-wrap text-wrap sm:gap-5 gap-x-2">
                        <h1 class="text-base font-semibold">Phone No.</h1>
                        <p class=" text-base"><?php echo e($user->phone); ?></p>
                    </section>
                    <section class="flex md:flex-row flex-col items-start flex-wrap text-wrap sm:gap-5 gap-x-2">
                        <h1 class="text-base font-semibold">Address</h1>
                        <p class=" text-base "><?php echo e($user->address); ?></p>
                    </section>
                    <section class="flex md:flex-row flex-col items-start flex-wrap text-wrap sm:gap-5 gap-x-2">
                        <h1 class="text-base font-semibold">School</h1>
                        <p class=" text-base "><?php echo e($user->school); ?></p>
                    </section>
                    <section class="flex md:flex-row flex-col items-start flex-wrap text-wrap sm:gap-5 gap-x-2">
                        <h1 class="text-base font-semibold">Account Started</h1>
                        <p class=" text-base "><?php echo e($userTimeStarted); ?></p>
                    </section>
                </div>
            </section>

            <section class="p-7 rounded-lg border border-gray-200 bg-white w-full flex flex-col gap-3">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['title' => 'Emergency Contact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Emergency Contact']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <hr>
                <div class="space-y-2">
                    <section class="flex md:flex-row flex-col items-start sm:gap-5 gap-x-2 text-wrap">
                        <h1 class="text-base font-semibold">Name</h1>
                        <p class=" text-base "><?php echo e($user->emergency_contact_fullname); ?></p>
                    </section>
                    <section class="flex md:flex-row flex-col items-start sm:gap-5 gap-x-2 text-wrap">
                        <h1 class="text-base font-semibold">Contact No.</h1>
                        <p class=" text-base ">+63 <?php echo e($user->emergency_contact_number); ?></p>
                    </section>
                    <section class="flex md:flex-row flex-col items-start sm:gap-5 gap-x-2 text-wrap">
                        <h1 class="text-base font-semibold">Address</h1>
                        <p class=" text-base "><?php echo e($user->emergency_contact_address); ?></p>
                    </section>
                </div>
            </section>
        </div>

        <div class="p-7 rounded-lg border border-gray-200 bg-white w-full">
            <div class="flex w-full justify-between gap-2 items-end mb-3">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-title','data' => ['title' => 'Request Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Request Status']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <a href="<?php echo e(route('users.request')); ?>"
                    class="lg:!text-sm text-xs text-[#F53C11] hover:underline underline-offset-4 cursor-pointer font-semibold">
                    View All
                </a>
            </div>
            <hr>

            
            <div class="overflow-auto h-[250px] w-full">
                <?php $__currentLoopData = $downloadRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('users.request')); ?>"
                        class="px-5 py-3 hover:bg-gray-100 border-b border-gray-300 w-full flex items-center justify-between gap-5">

                        <h1 class="truncate">Request for DTR Approval</h1>
                        <?php if($request['status'] === 'approved'): ?>
                            <div class="w-1/2">
                                <p class="lg:!text-sm text-xs font-semibold text-green-500 truncate">Has been approved.
                                </p>
                                
                            </div>
                        <?php endif; ?>
                        <?php if($request['status'] === 'declined'): ?>
                            <div class="w-1/2">
                                <p class="lg:!text-sm text-xs font-semibold text-red-500 truncate">Has been declined.
                                </p>
                                
                            </div>
                        <?php endif; ?>
                        <?php if($request['status'] === 'pending'): ?>
                            <div class="w-1/2">
                                <p class="lg:!text-sm text-xs font-semibold text-blue-500 truncate">Waiting for approval...
                                </p>
                                
                            </div>
                        <?php endif; ?>
                        <div>
                            <p class="text-sm font-semibold text-gray-600">Feb 5, 2025</p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Generate the small QR code when the page loads
        const qrCodeText = document.getElementById("hidden-data-qr-text").innerText;

        new QRCode(document.getElementById("small-qr-code-img"), {
            text: qrCodeText,
            width: 120,
            height: 120
        });

        // Add event listener to download QR image
        document.getElementById("download-qr-small-btn").addEventListener("click", function() {

            const qrCanvas = document.getElementById("small-qr-code-img").querySelector("canvas");
            if (qrCanvas) {
                // Get the image data URL (base64 format)
                const qrImage = qrCanvas.toDataURL("image/png");

                // Create an <a> tag dynamically for downloading the image
                const downloadLink = document.createElement("a");
                downloadLink.href = qrImage;
                downloadLink.download = "QR_Code.png"; // Set the default filename for download
                document.body.appendChild(downloadLink);
                downloadLink.click(); // Trigger the download
                document.body.removeChild(
                    downloadLink); // Clean up the link after triggering the download
            } else {
                console.error("QR code not found in the container!");
            }
        });
    });

    //this one for clicking the modal and passing some data in the enlarge modal
    document.addEventListener("DOMContentLoaded", function() {
        const qrButtons = document.querySelectorAll("[data-modal-target='qr-code-modal']");

        qrButtons.forEach(button => {
            button.addEventListener("click", function() {
                const qrText = this.getAttribute("data-qr-text");

                console.log("QR Modal Opened!", qrText);

                document.getElementById("qr-code-text").innerText = qrText;

                // Generate new QR code
                new QRCode(document.getElementById("large-qr-code-img"), {
                    text: qrText,
                    width: 350,
                    height: 350
                });

                // Show the modal
                document.getElementById("qr-code-modal").classList.remove("hidden");
            });
        });

        // Close modal
        document.querySelectorAll(".close-modal-button").forEach(button => {
            button.addEventListener("click", function() {
                document.getElementById("qr-code-modal").classList.add("hidden");
            });
        });
    });
</script>
<?php /**PATH /home/vol1_5/infinityfree.com/if0_38329388/htdocs/resources/views/users/dashboard.blade.php ENDPATH**/ ?>