@props(['path' => '', 'className' => ''])

<img class="{{ $className }} select-none" draggable="false" src="{{ asset($path) }}">
