@props(['width' => 'w-[250px]'])

<x-image path="resources/img/rweb_logo.png" className="{{ $width }} h-auto select-none" />
